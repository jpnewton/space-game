// Supabase configuration
// Replace these with your actual Supabase credentials from your project settings
const SUPABASE_URL = 'https://your-supabase-url.supabase.co';
const SUPABASE_KEY = 'your-supabase-anon-key';

// You can obtain these values from your Supabase project dashboard:
// 1. Go to https://app.supabase.com and sign in
// 2. Select your project
// 3. Go to Settings → API
// 4. Copy the URL and anon/public key